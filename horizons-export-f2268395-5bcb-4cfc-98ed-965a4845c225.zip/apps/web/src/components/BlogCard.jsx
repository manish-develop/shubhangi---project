
import React from 'react';
import { Clock, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import LazyImage from '@/components/LazyImage.jsx';

const BlogCard = ({ image, category, title, excerpt, readTime, slug = '/blog' }) => {
  return (
    <Link
      to={slug}
      className="group block bg-card rounded-xl overflow-hidden card-shadow hover:card-shadow-xl transition-all duration-300 hover:-translate-y-1"
    >
      <div className="relative h-48 overflow-hidden">
        <LazyImage
          src={image}
          alt={title}
          className="w-full h-full group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="text-xs font-medium text-white bg-primary px-3 py-1 rounded-full">
            {category}
          </span>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-3 text-foreground group-hover:text-primary transition-colors duration-300 line-clamp-2">
          {title}
        </h3>
        <p className="text-muted-foreground mb-4 leading-relaxed line-clamp-2">
          {excerpt}
        </p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{readTime} min read</span>
          </div>
          <div className="flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all duration-300">
            Read Article
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </Link>
  );
};

export default BlogCard;
