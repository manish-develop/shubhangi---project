
import React from 'react';
import { Phone, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';

const MobileBookingBar = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-primary shadow-lg border-t border-primary-foreground/10">
      <div className="grid grid-cols-2 gap-2 p-3">
        <a
          href="tel:+919876543210"
          className="flex items-center justify-center gap-2 bg-accent text-accent-foreground py-3 rounded-xl font-medium transition-all duration-300 active:scale-95"
        >
          <Phone className="w-5 h-5" />
          Call Now
        </a>
        <Link
          to="/contact"
          className="flex items-center justify-center gap-2 bg-primary-foreground text-primary py-3 rounded-xl font-medium transition-all duration-300 active:scale-95"
        >
          <Calendar className="w-5 h-5" />
          Book Appointment
        </Link>
      </div>
    </div>
  );
};

export default MobileBookingBar;
