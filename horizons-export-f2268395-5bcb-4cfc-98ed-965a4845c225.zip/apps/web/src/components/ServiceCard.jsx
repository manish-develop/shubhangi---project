
import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const ServiceCard = ({ icon: Icon, title, description, link = '/services' }) => {
  return (
    <div className="group bg-card rounded-xl p-6 card-shadow hover:card-shadow-xl transition-all duration-300 hover:-translate-y-1 border border-transparent hover:border-primary/20">
      <div className="w-14 h-14 rounded-xl bg-muted flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors duration-300">
        <Icon className="w-7 h-7 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-foreground">{title}</h3>
      <p className="text-muted-foreground mb-4 leading-relaxed">{description}</p>
      <Link
        to={link}
        className="inline-flex items-center gap-2 text-primary font-medium hover:gap-3 transition-all duration-300"
      >
        Learn More
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
};

export default ServiceCard;
