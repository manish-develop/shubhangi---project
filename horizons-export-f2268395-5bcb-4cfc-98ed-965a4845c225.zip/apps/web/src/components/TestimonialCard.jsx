
import React from 'react';
import { Star, Quote } from 'lucide-react';

const TestimonialCard = ({ name, city, rating = 5, testimonial, condition, avatar }) => {
  const initials = name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="bg-card rounded-xl p-6 card-shadow-lg border border-border/50 h-full flex flex-col">
      <Quote className="w-8 h-8 text-primary/20 mb-4" />
      <p className="text-foreground leading-relaxed mb-6 flex-grow italic">
        "{testimonial}"
      </p>
      <div className="flex items-center gap-4 pt-4 border-t border-border">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
          {initials}
        </div>
        <div className="flex-grow">
          <div className="font-semibold text-foreground">{name}</div>
          <div className="text-sm text-muted-foreground">{city}</div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div className="flex gap-0.5">
            {[...Array(rating)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-accent text-accent" />
            ))}
          </div>
          <div className="text-xs text-muted-foreground">{condition}</div>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;
