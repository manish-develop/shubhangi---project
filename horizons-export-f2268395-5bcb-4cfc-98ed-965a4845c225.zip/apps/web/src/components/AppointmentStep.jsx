
import React from 'react';
import { Check } from 'lucide-react';

const AppointmentStep = ({ step, currentStep, title, children }) => {
  const isActive = step === currentStep;
  const isCompleted = step < currentStep;

  return (
    <div className={`transition-all duration-300 ${isActive ? 'block' : 'hidden'}`}>
      <div className="flex items-center gap-4 mb-6">
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all duration-300 ${
            isCompleted
              ? 'bg-primary text-primary-foreground'
              : isActive
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-muted-foreground'
          }`}
        >
          {isCompleted ? <Check className="w-5 h-5" /> : step}
        </div>
        <h3 className="text-xl font-semibold text-foreground">{title}</h3>
      </div>
      <div className="pl-14">{children}</div>
    </div>
  );
};

export default AppointmentStep;
