import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Instagram, Facebook, Youtube, MessageCircle, MapPin, Phone, Mail, Clock } from 'lucide-react';
const Footer = () => {
  const quickLinks = [{
    path: '/',
    label: 'Home'
  }, {
    path: '/about',
    label: 'About'
  }, {
    path: '/services',
    label: 'Services'
  }, {
    path: '/blog',
    label: 'Blog'
  }, {
    path: '/contact',
    label: 'Contact'
  }, {
    path: '/contact',
    label: 'Appointment'
  }];
  const conditions = ['Skin Disorders', "Women's Health", 'Child Health', 'Thyroid', 'Joint Pain', 'Anxiety'];
  const socialLinks = [{
    icon: Instagram,
    href: 'https://instagram.com',
    label: 'Instagram'
  }, {
    icon: Facebook,
    href: 'https://facebook.com',
    label: 'Facebook'
  }, {
    icon: Youtube,
    href: 'https://youtube.com',
    label: 'YouTube'
  }, {
    icon: MessageCircle,
    href: 'https://wa.me/919876543210',
    label: 'WhatsApp'
  }];
  return <footer className="bg-primary text-primary-foreground">
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Leaf className="w-8 h-8" />
              <div>
                <div className="text-xl font-bold" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Dr. Shubhangi
                </div>
              </div>
            </Link>
            <p className="tagline text-primary-foreground/80 mb-6">Classical Homeopathy</p>
            <div className="flex gap-4">
              {socialLinks.map((social, index) => <a key={index} href={social.href} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-all duration-300" aria-label={social.label}>
                  <social.icon className="w-5 h-5" />
                </a>)}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4" style={{
            fontFamily: 'Playfair Display, serif'
          }}>
              Quick Links
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => <li key={index}>
                  <Link to={link.path} className="text-primary-foreground/80 hover:text-primary-foreground hover:translate-x-1 inline-block transition-all duration-300">
                    {link.label}
                  </Link>
                </li>)}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4" style={{
            fontFamily: 'Playfair Display, serif'
          }}>
              Conditions We Treat
            </h3>
            <ul className="space-y-3">
              {conditions.map((condition, index) => <li key={index}>
                  <Link to="/diseases" className="text-primary-foreground/80 hover:text-primary-foreground hover:translate-x-1 inline-block transition-all duration-300">
                    {condition}
                  </Link>
                </li>)}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4" style={{
            fontFamily: 'Playfair Display, serif'
          }}>
              Contact Info
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <span className="text-primary-foreground/80 text-sm">
                  ludhiana, punjab
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 flex-shrink-0" />
                <a href="tel:+919876543210" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-300 text-sm">
                  +91 88721 03215
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 flex-shrink-0" />
                <a href="mailto:drshubhangi@example.com" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-300 text-sm">
                  drshubhangi@example.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Clock className="w-5 h-5 mt-0.5 flex-shrink-0" />
                <div className="text-primary-foreground/80 text-sm">
                  <div>Mon-Sat: 10:00 AM - 7:00 PM</div>
                  <div>Sunday: Closed</div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-primary-foreground/10">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-primary-foreground/80">
            <p>&copy; 2026 Dr. Shubhangi. All rights reserved.</p>
            <div className="flex gap-6">
              <Link to="/privacy" className="hover:text-primary-foreground transition-colors duration-300">
                Privacy Policy
              </Link>
              <Link to="/terms" className="hover:text-primary-foreground transition-colors duration-300">
                Terms of Service
              </Link>
            </div>
          </div>
          <p className="text-xs text-primary-foreground/60 mt-4 text-center md:text-left">
            Please consult a qualified doctor before taking any medicine.
          </p>
        </div>
      </div>
    </footer>;
};
export default Footer;