
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from 'sonner';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ServicesPage from './pages/ServicesPage';
import DiseasesPage from './pages/DiseasesPage';
import BlogPage from './pages/BlogPage';
import TestimonialsPage from './pages/TestimonialsPage';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <Router>
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": "Dr. Shubhangi Homeopathic Clinic",
            "image": "https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3",
            "description": "Classical homeopathy clinic specializing in chronic diseases, women's health, and pediatric care. 15+ years experience, 5000+ patients treated.",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": "123 Wellness Street, Green Park",
              "addressLocality": "Mumbai",
              "addressRegion": "Maharashtra",
              "postalCode": "400001",
              "addressCountry": "IN"
            },
            "geo": {
              "@type": "GeoCoordinates",
              "latitude": 19.0344,
              "longitude": 72.8456
            },
            "telephone": "+919876543210",
            "email": "drshubhangi@example.com",
            "openingHoursSpecification": [
              {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                "opens": "10:00",
                "closes": "19:00"
              },
              {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": "Saturday",
                "opens": "10:00",
                "closes": "17:00"
              }
            ],
            "priceRange": "₹₹",
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.9",
              "reviewCount": "500"
            }
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Physician",
            "name": "Dr. Shubhangi",
            "medicalSpecialty": "Homeopathy",
            "description": "BHMS, MD Homeopathy specialist with 15+ years experience in classical homeopathy",
            "alumniOf": {
              "@type": "EducationalOrganization",
              "name": "Mumbai Homeopathic Medical College"
            },
            "memberOf": {
              "@type": "Organization",
              "name": "Central Council of Homeopathy"
            }
          })}
        </script>
      </Helmet>
      <ScrollToTop />
      <Toaster position="top-right" richColors />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/diseases" element={<DiseasesPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/testimonials" element={<TestimonialsPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="*" element={
          <div className="min-h-screen flex items-center justify-center bg-background">
            <div className="text-center">
              <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
              <p className="text-xl text-muted-foreground mb-8">Page not found</p>
              <a href="/" className="btn-primary">Back to Home</a>
            </div>
          </div>
        } />
      </Routes>
    </Router>
  );
}

export default App;
