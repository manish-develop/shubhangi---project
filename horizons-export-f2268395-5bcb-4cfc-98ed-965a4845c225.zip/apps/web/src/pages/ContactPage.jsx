
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { MapPin, Phone, Mail, Clock, MessageCircle } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';
import { toast } from 'sonner';
import { validateRequired, validateEmail, validatePhone, validateMessage } from '@/utils/validation.js';

const ContactPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateRequired(formData.name)) {
      toast.error('Please enter your name');
      return;
    }

    if (!validatePhone(formData.phone)) {
      toast.error('Please enter a valid 10-digit phone number');
      return;
    }

    if (!validateEmail(formData.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!validateRequired(formData.subject)) {
      toast.error('Please select a subject');
      return;
    }

    if (!validateMessage(formData.message)) {
      toast.error('Please enter a message of at least 10 characters');
      return;
    }

    toast.success('Message sent successfully. We will get back to you within 24 hours.');
    setFormData({ name: '', phone: '', email: '', subject: '', message: '' });
  };

  return (
    <>
      <Helmet>
        <title>Contact Dr. Shubhangi - Book Appointment | Homeopathy Clinic Mumbai</title>
        <meta name="description" content="Contact Dr. Shubhangi for homeopathic consultation. Book appointment online or visit our clinic in Mumbai. Call +91 98765 43210." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">Get in Touch</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Book your consultation or reach out with any questions about homeopathic treatment
              </p>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="grid lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2">
                <div className="bg-card rounded-2xl p-8 card-shadow-lg">
                  <h2 className="mb-8">Send Us a Message</h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Full Name</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                        placeholder="Enter your full name"
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">Phone Number</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                          placeholder="10-digit mobile number"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Email Address</label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                          placeholder="your.email@example.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Subject</label>
                      <select
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                      >
                        <option value="">Select a subject</option>
                        <option value="appointment">Book Appointment</option>
                        <option value="consultation">General Consultation</option>
                        <option value="followup">Follow-up Query</option>
                        <option value="feedback">Feedback</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Message</label>
                      <textarea
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        rows={6}
                        className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300 resize-none"
                        placeholder="Tell us about your health concern or query..."
                      />
                    </div>

                    <button type="submit" className="w-full btn-primary">
                      Send Message
                    </button>
                  </form>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Address</div>
                        <div className="text-muted-foreground">123 Wellness Street, Green Park, Mumbai 400001</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Phone</div>
                        <a href="tel:+919876543210" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          +91 98765 43210
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Email</div>
                        <a href="mailto:drshubhangi@example.com" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          drshubhangi@example.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Clinic Timings</div>
                        <div className="text-muted-foreground space-y-1">
                          <div>Mon-Fri: 10:00 AM - 7:00 PM</div>
                          <div>Saturday: 10:00 AM - 5:00 PM</div>
                          <div>Sunday: Closed</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <a
                      href="tel:+919876543210"
                      className="flex items-center gap-3 p-3 rounded-xl bg-background hover:bg-muted transition-all duration-300 border border-border hover:border-primary/20"
                    >
                      <Phone className="w-5 h-5 text-primary" />
                      <span className="text-sm font-medium">Call Now</span>
                    </a>

                    <a
                      href="https://wa.me/919876543210"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 rounded-xl bg-background hover:bg-muted transition-all duration-300 border border-border hover:border-primary/20"
                    >
                      <MessageCircle className="w-5 h-5 text-primary" />
                      <span className="text-sm font-medium">WhatsApp Us</span>
                    </a>

                    <a
                      href="mailto:drshubhangi@example.com"
                      className="flex items-center gap-3 p-3 rounded-xl bg-background hover:bg-muted transition-all duration-300 border border-border hover:border-primary/20"
                    >
                      <Mail className="w-5 h-5 text-primary" />
                      <span className="text-sm font-medium">Email Us</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Visit Our Clinic</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Conveniently located in the heart of Mumbai with ample parking
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="rounded-2xl overflow-hidden card-shadow-xl h-[500px]">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=72.8256%2C19.0144%2C72.8656%2C19.0544&layer=mapnik&marker=19.0344,72.8456"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    loading="lazy"
                    title="Clinic Location"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Parking Information</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Free parking available in the building premises. Additional street parking available nearby.
                  </p>
                </div>

                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Public Transport</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Nearest Metro: Green Park Station (5 min walk)<br />
                    Bus Stop: Wellness Street (2 min walk)
                  </p>
                </div>

                <a
                  href="https://maps.google.com/?q=19.0344,72.8456"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full btn-primary text-center"
                >
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ContactPage;
