
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Award, GraduationCap, Heart, Users, Shield, Sparkles } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import LazyImage from '@/components/LazyImage.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';

const AboutPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [bioRef, bioVisible] = useScrollAnimation(0.2);
  const [qualRef, qualVisible] = useScrollAnimation(0.2);
  const [philRef, philVisible] = useScrollAnimation(0.2);

  const qualifications = [
    {
      year: '2005',
      title: 'BHMS Degree',
      institution: 'Mumbai Homeopathic Medical College',
      description: 'Bachelor of Homeopathic Medicine and Surgery',
    },
    {
      year: '2008',
      title: 'MD Homeopathy',
      institution: 'National Institute of Homeopathy',
      description: 'Post-graduate specialization in Classical Homeopathy',
    },
    {
      year: '2009',
      title: 'Council Registration',
      institution: 'Central Council of Homeopathy',
      description: 'Licensed to practice homeopathy in India',
    },
    {
      year: '2010-Present',
      title: 'Private Practice',
      institution: 'Dr. Shubhangi Homeopathic Clinic',
      description: '15+ years of clinical experience treating thousands of patients',
    },
  ];

  const specializations = [
    { icon: Heart, title: "Women's Health", description: 'PCOD, menstrual disorders, menopause, fertility' },
    { icon: Users, title: 'Pediatric Care', description: 'Childhood ailments, developmental concerns, immunity' },
    { icon: Shield, title: 'Chronic Diseases', description: 'Diabetes, hypertension, autoimmune conditions' },
    { icon: Sparkles, title: 'Skin Disorders', description: 'Eczema, psoriasis, acne, allergic reactions' },
  ];

  return (
    <>
      <Helmet>
        <title>About Dr. Shubhangi - Classical Homeopathy Specialist | 15+ Years Experience</title>
        <meta name="description" content="Meet Dr. Shubhangi, BHMS, MD - Classical Homeopathy specialist with 15+ years experience. Expert in chronic diseases, women's health, and pediatric care." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">About Dr. Shubhangi</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Dedicated to healing through classical homeopathy with compassion, expertise, and a holistic approach to wellness
              </p>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
              <div className="relative">
                <div className="absolute -inset-4 bg-primary/10 rounded-full blur-3xl" />
                <div className="relative rounded-2xl overflow-hidden card-shadow-xl">
                  <LazyImage
                    src="https://images.unsplash.com/photo-1675270690434-aa99f4871e8a"
                    alt="Dr. Shubhangi - Classical Homeopathy Specialist"
                    className="w-full h-[600px]"
                  />
                </div>
                <div className="absolute top-6 right-6 bg-card p-4 rounded-xl card-shadow-lg">
                  <div className="text-sm font-medium text-muted-foreground mb-1">Qualified</div>
                  <div className="text-lg font-bold text-primary">BHMS, MD</div>
                </div>
              </div>

              <div ref={bioRef} className={bioVisible ? 'animate-slide-in-right' : 'opacity-0'}>
                <h2 className="mb-6">My Journey in Homeopathy</h2>
                
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  My journey into homeopathy began over 15 years ago, driven by a deep belief in the body's innate ability to heal itself. After completing my BHMS and MD in Homeopathy, I dedicated myself to mastering the principles of classical homeopathy as taught by Dr. Samuel Hahnemann.
                </p>

                <p className="text-muted-foreground mb-4 leading-relaxed">
                  Throughout my career, I have had the privilege of treating over 5,000 patients, witnessing remarkable transformations in their health and well-being. Each patient's journey reinforces my conviction that true healing addresses not just physical symptoms, but the emotional and mental aspects of health as well.
                </p>

                <p className="text-muted-foreground mb-4 leading-relaxed">
                  I specialize in chronic diseases, women's health issues, and pediatric care, areas where homeopathy has shown exceptional results. My approach combines thorough case-taking, constitutional analysis, and individualized remedy selection to ensure the best possible outcomes for each patient.
                </p>

                <p className="text-muted-foreground mb-4 leading-relaxed">
                  What sets my practice apart is the time and attention I give to understanding each patient's unique constitution, lifestyle, and emotional state. I believe that healing is a partnership between doctor and patient, and I am committed to empowering my patients with knowledge about their health.
                </p>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Beyond clinical practice, I am passionate about educating people about the benefits of homeopathy and promoting preventive healthcare. I regularly conduct workshops and write articles to spread awareness about natural healing methods.
                </p>

                <Link to="/contact" className="btn-primary">
                  Book a Consultation
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section ref={qualRef} className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Qualifications & Experience</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                A strong foundation in classical homeopathy backed by years of clinical practice
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="relative">
                <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-primary/20" />
                
                {qualifications.map((qual, index) => (
                  <div
                    key={index}
                    className={`relative pl-20 pb-12 last:pb-0 ${qualVisible ? 'animate-slide-in-left' : 'opacity-0'}`}
                    style={{ animationDelay: `${index * 150}ms` }}
                  >
                    <div className="absolute left-0 w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold card-shadow-lg">
                      <GraduationCap className="w-8 h-8" />
                    </div>
                    
                    <div className="bg-card rounded-xl p-6 card-shadow-lg">
                      <div className="text-sm font-medium text-primary mb-2">{qual.year}</div>
                      <h3 className="text-xl font-semibold mb-2">{qual.title}</h3>
                      <div className="text-muted-foreground font-medium mb-2">{qual.institution}</div>
                      <p className="text-muted-foreground">{qual.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section ref={philRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">My Philosophy</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Core beliefs that guide my practice and patient care
              </p>
            </div>

            <div className={`max-w-4xl mx-auto space-y-8 ${philVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <div className="bg-card rounded-2xl p-8 card-shadow-lg">
                <h3 className="text-2xl font-semibold mb-4">Treat the Person, Not the Disease</h3>
                <p className="text-muted-foreground leading-relaxed">
                  In classical homeopathy, we don't just treat symptoms or disease labels. We treat the whole person - their physical constitution, emotional state, mental patterns, and life circumstances. This holistic approach leads to deeper, more lasting healing.
                </p>
              </div>

              <div className="bg-card rounded-2xl p-8 card-shadow-lg">
                <h3 className="text-2xl font-semibold mb-4">Gentle, Natural Healing</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Homeopathic remedies work with the body's natural healing mechanisms, not against them. They are safe, non-toxic, and free from side effects, making them suitable for people of all ages, from infants to the elderly.
                </p>
              </div>

              <div className="bg-card rounded-2xl p-8 card-shadow-lg">
                <h3 className="text-2xl font-semibold mb-4">Root Cause Resolution</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Rather than suppressing symptoms, homeopathy addresses the underlying imbalance that causes disease. By treating the root cause, we achieve sustainable health improvements that last long after treatment ends.
                </p>
              </div>

              <div className="bg-card rounded-2xl p-8 card-shadow-lg">
                <h3 className="text-2xl font-semibold mb-4">Patient Empowerment</h3>
                <p className="text-muted-foreground leading-relaxed">
                  I believe in educating my patients about their health conditions and treatment options. An informed patient is an empowered patient who can make better decisions about their health and actively participate in their healing journey.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Areas of Specialization</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Expert care in conditions where homeopathy excels
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {specializations.map((spec, index) => (
                <div
                  key={index}
                  className="bg-card rounded-xl p-6 card-shadow-lg hover:card-shadow-xl transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                    <spec.icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{spec.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{spec.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="bg-primary text-primary-foreground rounded-2xl p-12 text-center card-shadow-xl">
              <h2 className="mb-6 text-primary-foreground">Patient Testimonial</h2>
              <blockquote className="text-xl italic mb-6 max-w-3xl mx-auto leading-relaxed">
                "Dr. Shubhangi changed my life. After years of struggling with chronic eczema and trying countless treatments, her homeopathic approach finally gave me lasting relief. She doesn't just treat symptoms - she truly understands her patients and addresses the root cause. I'm forever grateful."
              </blockquote>
              <div className="flex items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary-foreground/20 flex items-center justify-center text-lg font-semibold">
                  PS
                </div>
                <div className="text-left">
                  <div className="font-semibold">Priya Sharma</div>
                  <div className="text-sm text-primary-foreground/80">Mumbai</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section-padding bg-muted">
          <div className="container-custom text-center">
            <h2 className="mb-6">Ready to Start Your Healing Journey?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Book a consultation today and experience the gentle, effective power of classical homeopathy
            </p>
            <Link to="/contact" className="btn-primary">
              Book Appointment
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default AboutPage;
