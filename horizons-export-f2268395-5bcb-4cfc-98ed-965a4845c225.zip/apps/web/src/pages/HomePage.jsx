
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Award, Users, Heart, Star, Calendar, MapPin, Phone, Mail, Clock, ChevronLeft, ChevronRight, Search, Sparkles, Shield, Leaf, Stethoscope, Baby, Activity, Brain, Bone } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import StatCounter from '@/components/StatCounter.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';
import DiseaseCard from '@/components/DiseaseCard.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import TestimonialCard from '@/components/TestimonialCard.jsx';
import AppointmentStep from '@/components/AppointmentStep.jsx';
import WhatsAppButton from '@/components/WhatsAppButton.jsx';
import MobileBookingBar from '@/components/MobileBookingBar.jsx';
import LiveChat from '@/components/LiveChat.jsx';
import LazyImage from '@/components/LazyImage.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';
import { validateEmail, validatePhone, validateRequired } from '@/utils/validation.js';
import { toast } from 'sonner';

const HomePage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [aboutRef, aboutVisible] = useScrollAnimation(0.2);
  const [servicesRef, servicesVisible] = useScrollAnimation(0.2);
  const [appointmentRef, appointmentVisible] = useScrollAnimation(0.2);
  const [diseasesRef, diseasesVisible] = useScrollAnimation(0.2);
  const [blogRef, blogVisible] = useScrollAnimation(0.2);
  const [testimonialsRef, testimonialsVisible] = useScrollAnimation(0.2);

  const [currentStep, setCurrentStep] = useState(1);
  const [appointmentData, setAppointmentData] = useState({
    type: '',
    name: '',
    phone: '',
    email: '',
    concern: '',
    referral: '',
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [diseaseFilter, setDiseaseFilter] = useState('All');
  const [diseaseSearch, setDiseaseSearch] = useState('');

  const services = [
    { icon: Sparkles, title: 'Chronic Disease Management', description: 'Holistic treatment for long-term conditions like diabetes, hypertension, and autoimmune disorders.' },
    { icon: Heart, title: "Women's Health", description: 'Specialized care for PCOD, menstrual disorders, menopause, and fertility issues.' },
    { icon: Baby, title: 'Child Health', description: 'Gentle, safe treatment for common childhood ailments and developmental concerns.' },
    { icon: Shield, title: 'Skin Disorders', description: 'Effective solutions for eczema, psoriasis, acne, and other dermatological conditions.' },
    { icon: Activity, title: 'Thyroid Management', description: 'Natural approach to hypothyroidism, hyperthyroidism, and thyroid nodules.' },
    { icon: Brain, title: 'Mental Health', description: 'Compassionate care for anxiety, depression, stress, and sleep disorders.' },
    { icon: Bone, title: 'Joint & Bone Health', description: 'Relief from arthritis, osteoporosis, and musculoskeletal pain.' },
    { icon: Stethoscope, title: 'Respiratory Conditions', description: 'Treatment for asthma, allergies, sinusitis, and recurrent infections.' },
    { icon: Heart, title: 'Digestive Disorders', description: 'Solutions for IBS, acidity, constipation, and other GI issues.' },
    { icon: Sparkles, title: 'Autoimmune Diseases', description: 'Comprehensive care for lupus, rheumatoid arthritis, and other autoimmune conditions.' },
    { icon: Shield, title: 'Allergies & Immunity', description: 'Strengthen immunity and manage allergic reactions naturally.' },
    { icon: Activity, title: 'Lifestyle Diseases', description: 'Holistic approach to obesity, metabolic syndrome, and lifestyle-related conditions.' },
  ];

  const diseases = [
    { name: 'Psoriasis', description: 'Chronic skin condition causing red, scaly patches', category: 'Chronic', successRate: 87 },
    { name: 'PCOD/PCOS', description: 'Hormonal disorder affecting reproductive health', category: 'Women', successRate: 92 },
    { name: 'ADHD', description: 'Attention deficit hyperactivity disorder in children', category: 'Children', successRate: 78 },
    { name: 'Migraine', description: 'Severe recurring headaches with sensitivity', category: 'Chronic', successRate: 85 },
    { name: 'Kidney Stones', description: 'Hard deposits in kidneys causing pain', category: 'Acute', successRate: 81 },
    { name: 'Autism Spectrum', description: 'Developmental disorder affecting communication', category: 'Children', successRate: 73 },
    { name: 'Eczema', description: 'Inflammatory skin condition with itching', category: 'Chronic', successRate: 89 },
    { name: 'Hypothyroidism', description: 'Underactive thyroid gland condition', category: 'Chronic', successRate: 91 },
    { name: 'Asthma', description: 'Respiratory condition causing breathing difficulty', category: 'Chronic', successRate: 84 },
    { name: 'Tonsillitis', description: 'Inflammation of tonsils causing sore throat', category: 'Acute', successRate: 93 },
    { name: 'Depression', description: 'Mental health disorder affecting mood', category: 'Mental Health', successRate: 79 },
    { name: 'Arthritis', description: 'Joint inflammation causing pain and stiffness', category: 'Chronic', successRate: 82 },
  ];

  const blogs = [
    {
      image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528',
      category: 'Wellness',
      title: 'Understanding the Principles of Classical Homeopathy',
      excerpt: 'Discover how classical homeopathy treats the whole person, not just symptoms, for lasting health.',
      readTime: 5,
    },
    {
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b',
      category: 'Nutrition',
      title: 'Diet and Lifestyle Tips for Better Immunity',
      excerpt: 'Simple dietary changes and lifestyle habits that can strengthen your immune system naturally.',
      readTime: 7,
    },
    {
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b',
      category: 'Mental Health',
      title: 'Managing Stress and Anxiety Naturally',
      excerpt: 'Holistic approaches to reduce stress and anxiety without relying on conventional medications.',
      readTime: 6,
    },
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      city: 'Mumbai',
      rating: 5,
      testimonial: 'Dr. Shubhangi cured my chronic eczema that I had for 8 years. Her approach is truly holistic and she takes time to understand the root cause. Highly recommended!',
      condition: 'Eczema',
    },
    {
      name: 'Rajesh Kumar',
      city: 'Pune',
      rating: 5,
      testimonial: 'My daughter had recurrent tonsillitis and was advised surgery. After 6 months of treatment with Dr. Shubhangi, she has had no episodes. Thank you!',
      condition: 'Tonsillitis',
    },
    {
      name: 'Anita Desai',
      city: 'Delhi',
      rating: 5,
      testimonial: 'I struggled with PCOD for years. Dr. Shubhangi not only helped regulate my cycles but also improved my overall health. Her treatment is gentle yet effective.',
      condition: 'PCOD',
    },
    {
      name: 'Vikram Patel',
      city: 'Bangalore',
      rating: 5,
      testimonial: 'Suffered from severe migraines for 10 years. Conventional medicine only provided temporary relief. Dr. Shubhangi treatment has reduced frequency by 90%.',
      condition: 'Migraine',
    },
  ];

  const handleAppointmentSubmit = (e) => {
    e.preventDefault();

    if (currentStep === 1) {
      if (!appointmentData.type) {
        toast.error('Please select an appointment type');
        return;
      }
      setCurrentStep(2);
    } else if (currentStep === 2) {
      if (!validateRequired(appointmentData.name)) {
        toast.error('Please enter your name');
        return;
      }
      if (!validatePhone(appointmentData.phone)) {
        toast.error('Please enter a valid 10-digit phone number');
        return;
      }
      if (!validateEmail(appointmentData.email)) {
        toast.error('Please enter a valid email address');
        return;
      }
      setCurrentStep(3);
    } else if (currentStep === 3) {
      if (!validateRequired(appointmentData.concern)) {
        toast.error('Please describe your health concern');
        return;
      }
      setCurrentStep(4);
    } else if (currentStep === 4) {
      const confirmationNumber = `APT${Math.floor(100000 + Math.random() * 900000)}`;
      setShowSuccess(true);
      toast.success(`Appointment booked successfully! Confirmation: ${confirmationNumber}`);
    }
  };

  const filteredDiseases = diseases.filter((disease) => {
    const matchesFilter = diseaseFilter === 'All' || disease.category === diseaseFilter;
    const matchesSearch = disease.name.toLowerCase().includes(diseaseSearch.toLowerCase()) ||
                          disease.description.toLowerCase().includes(diseaseSearch.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <>
      <Helmet>
        <title>Dr. Shubhangi - Classical Homeopathy | Heal Naturally, Live Fully</title>
        <meta name="description" content="Expert homeopathic treatment for chronic diseases, women's health, child health, and more. 15+ years experience, 5000+ patients treated successfully." />
      </Helmet>

      <Header />
      <WhatsAppButton />
      <MobileBookingBar />
      <LiveChat />

      <main>
        <section
          ref={heroRef}
          className="min-h-screen flex items-center gradient-cream-mint leaf-pattern pt-20"
        >
          <div className="container-custom">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className={`${heroVisible ? 'animate-slide-in-left' : 'opacity-0'}`}>
                <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
                  🌿 Trusted Classical Homeopathy
                </div>
                <h1 className="mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Heal Naturally. Live Fully.
                </h1>
                <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                  Experience the gentle power of classical homeopathy. Personalized treatment for chronic conditions, women's health, child care, and holistic wellness.
                </p>
                <div className="flex flex-wrap gap-4 mb-8">
                  <Link to="/contact" className="btn-primary">
                    Book Consultation
                  </Link>
                  <Link to="/about" className="btn-outline">
                    Learn More
                  </Link>
                </div>
                <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-primary" />
                    <span>BHMS, MD Homeopathy</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-primary" />
                    <span>5000+ Happy Patients</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-accent fill-accent" />
                    <span>4.9 Rating</span>
                  </div>
                </div>
              </div>

              <div className={`relative ${heroVisible ? 'animate-slide-in-right' : 'opacity-0'}`}>
                <div className="relative rounded-2xl overflow-hidden card-shadow-xl">
                  <LazyImage
                    src="https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3"
                    alt="Dr. Shubhangi - Classical Homeopathy Specialist"
                    className="w-full h-[500px]"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground p-6 rounded-2xl card-shadow-xl max-w-xs">
                  <div className="flex items-center gap-3 mb-2">
                    <Calendar className="w-6 h-6" />
                    <span className="font-semibold">Next Available Slot</span>
                  </div>
                  <p className="text-2xl font-bold">Today 4:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-secondary py-12">
          <div className="container-custom">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <StatCounter end={15} suffix="+" label="Years Experience" icon={Award} />
              <StatCounter end={5000} suffix="+" label="Patients Treated" icon={Users} />
              <StatCounter end={100} suffix="+" label="Conditions Treated" icon={Heart} />
              <StatCounter end={4.9} label="Average Rating" icon={Star} suffix="★" />
            </div>
          </div>
        </section>

        <section ref={aboutRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className={`${aboutVisible ? 'animate-slide-in-left' : 'opacity-0'}`}>
                <div className="relative">
                  <div className="absolute -inset-4 bg-primary/10 rounded-full blur-3xl" />
                  <div className="relative rounded-2xl overflow-hidden card-shadow-xl">
                    <LazyImage
                      src="https://images.unsplash.com/photo-1675270690434-aa99f4871e8a"
                      alt="Dr. Shubhangi - Homeopathic Doctor"
                      className="w-full h-[500px]"
                    />
                  </div>
                  <div className="absolute top-6 right-6 bg-card p-4 rounded-xl card-shadow-lg">
                    <div className="text-sm font-medium text-muted-foreground mb-1">Qualified</div>
                    <div className="text-lg font-bold text-primary">BHMS, MD</div>
                  </div>
                </div>
              </div>

              <div className={`${aboutVisible ? 'animate-slide-in-right' : 'opacity-0'}`}>
                <h2 className="mb-6">About Dr. Shubhangi</h2>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  With over 15 years of dedicated practice in classical homeopathy, Dr. Shubhangi has helped thousands of patients achieve lasting health through gentle, natural treatment.
                </p>
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  Her approach combines deep understanding of homeopathic principles with modern diagnostic methods, ensuring comprehensive care tailored to each individual's unique constitution.
                </p>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Specializing in chronic diseases, women's health, and pediatric care, she believes in treating the root cause rather than suppressing symptoms.
                </p>

                <div className="grid sm:grid-cols-2 gap-4 mb-8">
                  <div className="flex items-start gap-3">
                    <Award className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold mb-1">BHMS Degree</div>
                      <div className="text-sm text-muted-foreground">Bachelor of Homeopathic Medicine</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Award className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold mb-1">MD Homeopathy</div>
                      <div className="text-sm text-muted-foreground">Post-graduate specialization</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Shield className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold mb-1">Council Registered</div>
                      <div className="text-sm text-muted-foreground">Licensed practitioner</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Users className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <div className="font-semibold mb-1">15+ Years</div>
                      <div className="text-sm text-muted-foreground">Clinical experience</div>
                    </div>
                  </div>
                </div>

                <Link to="/about" className="btn-primary">
                  Know More About Me
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section ref={servicesRef} className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Our Services</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Comprehensive homeopathic care for a wide range of health conditions
              </p>
            </div>

            <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-6 ${servicesVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              {services.map((service, index) => (
                <div
                  key={index}
                  style={{ animationDelay: `${index * 100}ms` }}
                  className={servicesVisible ? 'animate-slide-up' : 'opacity-0'}
                >
                  <ServiceCard {...service} />
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link to="/services" className="btn-primary">
                View All Services
              </Link>
            </div>
          </div>
        </section>

        <section ref={appointmentRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="grid lg:grid-cols-3 gap-12">
              <div className="lg:col-span-2">
                <h2 className="mb-8">Book Your Appointment</h2>

                {!showSuccess ? (
                  <form onSubmit={handleAppointmentSubmit} className="bg-card rounded-2xl p-8 card-shadow-lg">
                    <div className="flex items-center gap-2 mb-8">
                      {[1, 2, 3, 4].map((step) => (
                        <React.Fragment key={step}>
                          <div
                            className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all duration-300 ${
                              step <= currentStep
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-muted text-muted-foreground'
                            }`}
                          >
                            {step}
                          </div>
                          {step < 4 && (
                            <div
                              className={`flex-1 h-1 rounded transition-all duration-300 ${
                                step < currentStep ? 'bg-primary' : 'bg-muted'
                              }`}
                            />
                          )}
                        </React.Fragment>
                      ))}
                    </div>

                    <AppointmentStep step={1} currentStep={currentStep} title="Select Appointment Type">
                      <div className="grid sm:grid-cols-2 gap-4">
                        {['First Consultation', 'Follow-up Visit', 'Online Consultation', 'Emergency'].map((type) => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => setAppointmentData({ ...appointmentData, type })}
                            className={`p-4 rounded-xl border-2 transition-all duration-300 text-left ${
                              appointmentData.type === type
                                ? 'border-primary bg-primary/5'
                                : 'border-border hover:border-primary/50'
                            }`}
                          >
                            <div className="font-semibold">{type}</div>
                          </button>
                        ))}
                      </div>
                    </AppointmentStep>

                    <AppointmentStep step={2} currentStep={currentStep} title="Personal Details">
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Full Name</label>
                          <input
                            type="text"
                            value={appointmentData.name}
                            onChange={(e) => setAppointmentData({ ...appointmentData, name: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                            placeholder="Enter your full name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Phone Number</label>
                          <input
                            type="tel"
                            value={appointmentData.phone}
                            onChange={(e) => setAppointmentData({ ...appointmentData, phone: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                            placeholder="10-digit mobile number"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Email Address</label>
                          <input
                            type="email"
                            value={appointmentData.email}
                            onChange={(e) => setAppointmentData({ ...appointmentData, email: e.target.value })}
                            className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                            placeholder="your.email@example.com"
                          />
                        </div>
                      </div>
                    </AppointmentStep>

                    <AppointmentStep step={3} currentStep={currentStep} title="Health Concern">
                      <div>
                        <label className="block text-sm font-medium mb-2">Describe your health concern</label>
                        <textarea
                          value={appointmentData.concern}
                          onChange={(e) => setAppointmentData({ ...appointmentData, concern: e.target.value })}
                          rows={6}
                          className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300 resize-none"
                          placeholder="Please provide details about your symptoms, duration, and any previous treatments..."
                        />
                      </div>
                    </AppointmentStep>

                    <AppointmentStep step={4} currentStep={currentStep} title="How did you hear about us?">
                      <div className="grid sm:grid-cols-2 gap-4">
                        {['Google Search', 'Social Media', 'Friend/Family', 'Doctor Referral', 'Advertisement', 'Other'].map((source) => (
                          <button
                            key={source}
                            type="button"
                            onClick={() => setAppointmentData({ ...appointmentData, referral: source })}
                            className={`p-4 rounded-xl border-2 transition-all duration-300 text-left ${
                              appointmentData.referral === source
                                ? 'border-primary bg-primary/5'
                                : 'border-border hover:border-primary/50'
                            }`}
                          >
                            <div className="font-semibold">{source}</div>
                          </button>
                        ))}
                      </div>
                    </AppointmentStep>

                    <div className="flex gap-4 mt-8">
                      {currentStep > 1 && (
                        <button
                          type="button"
                          onClick={() => setCurrentStep(currentStep - 1)}
                          className="btn-outline"
                        >
                          Previous
                        </button>
                      )}
                      <button type="submit" className="btn-primary flex-1">
                        {currentStep === 4 ? 'Confirm Appointment' : 'Next Step'}
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="bg-card rounded-2xl p-8 card-shadow-lg text-center">
                    <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                      <Calendar className="w-10 h-10 text-primary" />
                    </div>
                    <h3 className="text-2xl font-semibold mb-4">Appointment Confirmed</h3>
                    <p className="text-muted-foreground mb-6">
                      Thank you for booking with us. We have sent a confirmation to your email and phone number.
                    </p>
                    <div className="bg-muted rounded-xl p-4 mb-6">
                      <div className="text-sm text-muted-foreground mb-1">Confirmation Number</div>
                      <div className="text-2xl font-bold text-primary">APT{Math.floor(100000 + Math.random() * 900000)}</div>
                    </div>
                    <button
                      onClick={() => {
                        setShowSuccess(false);
                        setCurrentStep(1);
                        setAppointmentData({ type: '', name: '', phone: '', email: '', concern: '', referral: '' });
                      }}
                      className="btn-primary"
                    >
                      Book Another Appointment
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Clinic Timings</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Monday - Friday</span>
                      <span className="font-medium">10:00 AM - 7:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Saturday</span>
                      <span className="font-medium">10:00 AM - 5:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sunday</span>
                      <span className="font-medium text-destructive">Closed</span>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Address</div>
                        <div className="text-muted-foreground">123 Wellness Street, Green Park, Mumbai 400001</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Phone</div>
                        <a href="tel:+919876543210" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          +91 98765 43210
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Email</div>
                        <a href="mailto:drshubhangi@example.com" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          drshubhangi@example.com
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-card rounded-2xl overflow-hidden card-shadow-lg">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=72.8256%2C19.0144%2C72.8656%2C19.0544&layer=mapnik&marker=19.0344,72.8456"
                    width="100%"
                    height="200"
                    style={{ border: 0 }}
                    loading="lazy"
                    title="Clinic Location Map"
                  />
                </div>

                <a
                  href="https://wa.me/919876543210"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-[#25D366] text-white py-3 rounded-xl font-medium text-center hover:bg-[#20BA5A] transition-all duration-300 active:scale-[0.98]"
                >
                  Chat on WhatsApp
                </a>
              </div>
            </div>
          </div>
        </section>

        <section ref={diseasesRef} className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Conditions We Treat</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Specialized homeopathic treatment for a wide range of health conditions
              </p>
            </div>

            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={diseaseSearch}
                  onChange={(e) => setDiseaseSearch(e.target.value)}
                  placeholder="Search a condition..."
                  className="w-full pl-12 pr-4 py-4 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                />
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3 mb-12">
              {['All', 'Chronic', 'Acute', 'Children', 'Women', 'Mental Health'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setDiseaseFilter(filter)}
                  className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                    diseaseFilter === filter
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background text-foreground hover:bg-primary/10 border border-border'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-6 ${diseasesVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              {filteredDiseases.map((disease, index) => (
                <div
                  key={index}
                  style={{ animationDelay: `${index * 50}ms` }}
                  className={diseasesVisible ? 'animate-slide-up' : 'opacity-0'}
                >
                  <DiseaseCard {...disease} />
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link to="/diseases" className="btn-primary">
                View All Conditions
              </Link>
            </div>
          </div>
        </section>

        <section ref={blogRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Latest from Our Blog</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Expert insights on health, wellness, and homeopathy
              </p>
            </div>

            <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-8 ${blogVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              {blogs.map((blog, index) => (
                <div
                  key={index}
                  style={{ animationDelay: `${index * 100}ms` }}
                  className={blogVisible ? 'animate-slide-up' : 'opacity-0'}
                >
                  <BlogCard {...blog} />
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link to="/blog" className="btn-primary">
                View All Articles
              </Link>
            </div>
          </div>
        </section>

        <section ref={testimonialsRef} className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">What Our Patients Say</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Real stories from real people who found healing through homeopathy
              </p>
            </div>

            <div className="relative max-w-4xl mx-auto">
              <div className="overflow-hidden">
                <div
                  className="flex transition-transform duration-500 ease-out"
                  style={{ transform: `translateX(-${currentTestimonial * 100}%)` }}
                >
                  {testimonials.map((testimonial, index) => (
                    <div key={index} className="w-full flex-shrink-0 px-4">
                      <TestimonialCard {...testimonial} />
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setCurrentTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
                className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-12 h-12 rounded-full bg-card card-shadow-lg flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              <button
                onClick={() => setCurrentTestimonial((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))}
                className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-12 h-12 rounded-full bg-card card-shadow-lg flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

              <div className="flex justify-center gap-2 mt-8">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      currentTestimonial === index ? 'bg-primary w-8' : 'bg-border'
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  />
                ))}
              </div>
            </div>

            <div className="text-center mt-12">
              <div className="inline-flex items-center gap-3 bg-card px-6 py-3 rounded-xl card-shadow">
                <Star className="w-6 h-6 fill-accent text-accent" />
                <div>
                  <div className="text-2xl font-bold text-foreground">4.9/5</div>
                  <div className="text-sm text-muted-foreground">Google Reviews</div>
                </div>
              </div>
            </div>

            <div className="text-center mt-8">
              <Link to="/testimonials" className="btn-primary">
                Read More Testimonials
              </Link>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Visit Our Clinic</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Conveniently located in the heart of Mumbai
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="rounded-2xl overflow-hidden card-shadow-xl h-[400px]">
                  <iframe
                    src="https://www.openstreetmap.org/export/embed.html?bbox=72.8256%2C19.0144%2C72.8656%2C19.0544&layer=mapnik&marker=19.0344,72.8456"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    loading="lazy"
                    title="Clinic Location"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-card rounded-2xl p-6 card-shadow-lg">
                  <h3 className="text-lg font-semibold mb-4">Clinic Information</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Address</div>
                        <div className="text-muted-foreground">123 Wellness Street, Green Park, Mumbai 400001</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Phone</div>
                        <a href="tel:+919876543210" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          +91 98765 43210
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Email</div>
                        <a href="mailto:drshubhangi@example.com" className="text-muted-foreground hover:text-primary transition-colors duration-300">
                          drshubhangi@example.com
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <div className="font-medium mb-1">Timings</div>
                        <div className="text-muted-foreground">Mon-Sat: 10 AM - 7 PM</div>
                      </div>
                    </div>
                  </div>
                </div>

                <a
                  href="https://maps.google.com/?q=19.0344,72.8456"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full btn-primary text-center"
                >
                  Get Directions
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default HomePage;
