
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Search } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BlogCard from '@/components/BlogCard.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';

const BlogPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const blogs = [
    {
      image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528',
      category: 'Wellness',
      title: 'Understanding the Principles of Classical Homeopathy',
      excerpt: 'Discover how classical homeopathy treats the whole person, not just symptoms, for lasting health and wellness.',
      readTime: 5,
    },
    {
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b',
      category: 'Nutrition',
      title: 'Diet and Lifestyle Tips for Better Immunity',
      excerpt: 'Simple dietary changes and lifestyle habits that can strengthen your immune system naturally and effectively.',
      readTime: 7,
    },
    {
      image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b',
      category: 'Mental Health',
      title: 'Managing Stress and Anxiety Naturally',
      excerpt: 'Holistic approaches to reduce stress and anxiety without relying on conventional medications or harmful substances.',
      readTime: 6,
    },
    {
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d',
      category: 'Women\'s Health',
      title: 'Natural Solutions for PCOD and Hormonal Balance',
      excerpt: 'How homeopathy addresses the root cause of PCOD and helps restore hormonal balance naturally.',
      readTime: 8,
    },
    {
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88',
      category: 'Child Health',
      title: 'Boosting Your Child\'s Immunity the Natural Way',
      excerpt: 'Safe, gentle methods to strengthen your child\'s immune system and reduce recurrent infections.',
      readTime: 6,
    },
    {
      image: 'https://images.unsplash.com/photo-1559757175-5700dde675bc',
      category: 'Skin Care',
      title: 'Treating Eczema and Psoriasis Holistically',
      excerpt: 'Understanding the constitutional approach to chronic skin conditions for lasting relief.',
      readTime: 7,
    },
    {
      image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773',
      category: 'Wellness',
      title: 'The Mind-Body Connection in Healing',
      excerpt: 'How emotional and mental states affect physical health and the role of homeopathy in holistic healing.',
      readTime: 5,
    },
    {
      image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b',
      category: 'Chronic Diseases',
      title: 'Managing Thyroid Disorders Naturally',
      excerpt: 'Constitutional homeopathic treatment for hypothyroidism and hyperthyroidism without side effects.',
      readTime: 8,
    },
    {
      image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae',
      category: 'Nutrition',
      title: 'Anti-Inflammatory Foods for Joint Health',
      excerpt: 'Dietary recommendations to reduce inflammation and support homeopathic treatment for arthritis.',
      readTime: 6,
    },
  ];

  const categories = ['All', ...new Set(blogs.map(blog => blog.category))];

  const filteredBlogs = blogs.filter((blog) => {
    const matchesCategory = categoryFilter === 'All' || blog.category === categoryFilter;
    const matchesSearch = blog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          blog.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <>
      <Helmet>
        <title>Health Blog - Dr. Shubhangi | Homeopathy, Wellness & Natural Healing</title>
        <meta name="description" content="Expert insights on homeopathy, natural healing, wellness, nutrition, and holistic health from Dr. Shubhangi." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">Health & Wellness Blog</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Expert insights on homeopathy, natural healing, and holistic wellness
              </p>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search articles..."
                  className="w-full pl-12 pr-4 py-4 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                />
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3 mb-12">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setCategoryFilter(category)}
                  className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                    categoryFilter === category
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background text-foreground hover:bg-primary/10 border border-border'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredBlogs.map((blog, index) => (
                <BlogCard key={index} {...blog} />
              ))}
            </div>

            {filteredBlogs.length === 0 && (
              <div className="text-center py-12">
                <p className="text-xl text-muted-foreground">No articles found matching your search.</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default BlogPage;
