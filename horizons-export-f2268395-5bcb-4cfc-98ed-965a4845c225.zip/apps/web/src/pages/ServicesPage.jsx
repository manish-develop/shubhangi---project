
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Sparkles, Heart, Baby, Shield, Activity, Brain, Bone, Stethoscope, Check, X } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ServiceCard from '@/components/ServiceCard.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const ServicesPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [servicesRef, servicesVisible] = useScrollAnimation(0.2);
  const [comparisonRef, comparisonVisible] = useScrollAnimation(0.2);
  const [faqRef, faqVisible] = useScrollAnimation(0.2);

  const services = [
    { icon: Sparkles, title: 'Chronic Disease Management', description: 'Comprehensive treatment for diabetes, hypertension, autoimmune disorders, and other long-term conditions using constitutional homeopathic remedies.' },
    { icon: Heart, title: "Women's Health", description: 'Specialized care for PCOD/PCOS, menstrual irregularities, menopause symptoms, fertility issues, and hormonal imbalances.' },
    { icon: Baby, title: 'Child Health & Development', description: 'Gentle, safe treatment for common childhood ailments, developmental concerns, behavioral issues, and immunity building.' },
    { icon: Shield, title: 'Skin Disorders', description: 'Effective solutions for eczema, psoriasis, acne, urticaria, vitiligo, and other dermatological conditions.' },
    { icon: Activity, title: 'Thyroid Management', description: 'Natural approach to hypothyroidism, hyperthyroidism, thyroid nodules, and related metabolic disorders.' },
    { icon: Brain, title: 'Mental Health Support', description: 'Compassionate care for anxiety, depression, stress disorders, insomnia, OCD, and other psychological conditions.' },
    { icon: Bone, title: 'Joint & Bone Health', description: 'Relief from arthritis, osteoporosis, gout, sciatica, and musculoskeletal pain without side effects.' },
    { icon: Stethoscope, title: 'Respiratory Conditions', description: 'Treatment for asthma, allergic rhinitis, sinusitis, bronchitis, and recurrent respiratory infections.' },
    { icon: Heart, title: 'Digestive Disorders', description: 'Solutions for IBS, acidity, GERD, constipation, colitis, and other gastrointestinal issues.' },
    { icon: Sparkles, title: 'Autoimmune Diseases', description: 'Comprehensive care for lupus, rheumatoid arthritis, Hashimoto thyroiditis, and other autoimmune conditions.' },
    { icon: Shield, title: 'Allergies & Immunity', description: 'Strengthen immune system and manage allergic reactions, food allergies, and seasonal allergies naturally.' },
    { icon: Activity, title: 'Lifestyle Diseases', description: 'Holistic approach to obesity, metabolic syndrome, fatty liver, and other lifestyle-related conditions.' },
  ];

  const comparisonData = [
    {
      aspect: 'Approach',
      homeopathy: 'Treats the whole person - physical, mental, emotional',
      conventional: 'Focuses primarily on physical symptoms',
    },
    {
      aspect: 'Side Effects',
      homeopathy: 'No side effects, safe for all ages',
      conventional: 'May have significant side effects',
    },
    {
      aspect: 'Treatment Duration',
      homeopathy: 'Longer initial period, but lasting results',
      conventional: 'Quick symptom relief, may need ongoing medication',
    },
    {
      aspect: 'Root Cause',
      homeopathy: 'Addresses underlying imbalance',
      conventional: 'Often suppresses symptoms',
    },
    {
      aspect: 'Individualization',
      homeopathy: 'Highly personalized based on constitution',
      conventional: 'Standardized protocols for conditions',
    },
  ];

  const faqs = [
    {
      question: 'How long does homeopathic treatment take to show results?',
      answer: 'The timeline varies depending on the condition and individual. Acute conditions may show improvement within days, while chronic conditions typically require 3-6 months for significant improvement. Constitutional treatment works gradually but provides lasting results.',
    },
    {
      question: 'Is homeopathy safe for children and pregnant women?',
      answer: 'Yes, homeopathy is completely safe for children, pregnant women, and nursing mothers. The remedies are non-toxic, have no side effects, and work gently with the body natural healing mechanisms.',
    },
    {
      question: 'Can I take homeopathic remedies alongside conventional medicine?',
      answer: 'In most cases, yes. Homeopathic remedies can be taken alongside conventional medications. However, it important to inform both your homeopath and conventional doctor about all treatments you are receiving.',
    },
    {
      question: 'What should I expect during my first consultation?',
      answer: 'The first consultation typically lasts 60-90 minutes. I will take a detailed case history covering your physical symptoms, emotional state, lifestyle, family history, and overall constitution. This comprehensive understanding helps me select the most appropriate remedy for you.',
    },
    {
      question: 'Do I need to follow any dietary restrictions during treatment?',
      answer: 'Generally, no strict dietary restrictions are required. However, I may recommend avoiding certain foods or substances that interfere with remedy action, such as coffee, mint, or strong-smelling substances around the time of taking remedies.',
    },
    {
      question: 'How often will I need follow-up appointments?',
      answer: 'Follow-up frequency depends on your condition. For chronic cases, follow-ups are typically scheduled every 4-6 weeks initially, then extended as improvement occurs. Acute conditions may require more frequent monitoring.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Homeopathic Services - Dr. Shubhangi | Chronic Diseases, Women's Health, Child Care</title>
        <meta name="description" content="Comprehensive homeopathic treatment services for chronic diseases, women's health, pediatric care, skin disorders, and more. Safe, natural, effective healing." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">Our Services</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Comprehensive homeopathic care for a wide range of health conditions, delivered with expertise and compassion
              </p>
            </div>
          </div>
        </section>

        <section ref={servicesRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">What We Treat</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Specialized homeopathic treatment for diverse health conditions
              </p>
            </div>

            <div className={`grid md:grid-cols-2 lg:grid-cols-3 gap-6 ${servicesVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              {services.map((service, index) => (
                <div
                  key={index}
                  style={{ animationDelay: `${index * 50}ms` }}
                  className={servicesVisible ? 'animate-slide-up' : 'opacity-0'}
                >
                  <ServiceCard {...service} />
                </div>
              ))}
            </div>
          </div>
        </section>

        <section ref={comparisonRef} className="section-padding bg-muted">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Homeopathy vs Conventional Medicine</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Understanding the differences in approach and philosophy
              </p>
            </div>

            <div className={`max-w-5xl mx-auto ${comparisonVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <div className="bg-card rounded-2xl overflow-hidden card-shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-primary text-primary-foreground">
                        <th className="px-6 py-4 text-left font-semibold">Aspect</th>
                        <th className="px-6 py-4 text-left font-semibold">Homeopathy</th>
                        <th className="px-6 py-4 text-left font-semibold">Conventional Medicine</th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisonData.map((row, index) => (
                        <tr key={index} className="border-b border-border last:border-0">
                          <td className="px-6 py-4 font-medium">{row.aspect}</td>
                          <td className="px-6 py-4">
                            <div className="flex items-start gap-2">
                              <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{row.homeopathy}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-start gap-2">
                              <X className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{row.conventional}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-8 bg-primary/10 border border-primary/20 rounded-xl p-6">
                <p className="text-sm text-foreground leading-relaxed">
                  <strong>Note:</strong> This comparison is for educational purposes. Both systems have their place in healthcare. Homeopathy excels in chronic conditions and constitutional treatment, while conventional medicine is essential for emergencies and acute life-threatening situations.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section ref={faqRef} className="section-padding bg-background">
          <div className="container-custom">
            <div className="text-center mb-12">
              <h2 className="mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Common questions about homeopathic treatment
              </p>
            </div>

            <div className={`max-w-3xl mx-auto ${faqVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <Accordion type="single" collapsible className="space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`item-${index}`}
                    className="bg-card rounded-xl px-6 card-shadow border-0"
                  >
                    <AccordionTrigger className="text-left font-semibold hover:no-underline py-6">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed pb-6">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        <section className="section-padding bg-primary text-primary-foreground">
          <div className="container-custom text-center">
            <h2 className="mb-6 text-primary-foreground">Ready to Experience Natural Healing?</h2>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Book a consultation today and take the first step towards holistic wellness
            </p>
            <Link to="/contact" className="btn-secondary">
              Book Consultation
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default ServicesPage;
