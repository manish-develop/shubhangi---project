
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Search } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import DiseaseCard from '@/components/DiseaseCard.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';

const DiseasesPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [diseaseFilter, setDiseaseFilter] = useState('All');
  const [diseaseSearch, setDiseaseSearch] = useState('');

  const diseases = [
    { name: 'Psoriasis', description: 'Chronic autoimmune skin condition causing red, scaly patches that can be itchy and painful', category: 'Chronic', successRate: 87 },
    { name: 'PCOD/PCOS', description: 'Hormonal disorder affecting reproductive health, causing irregular periods and fertility issues', category: 'Women', successRate: 92 },
    { name: 'ADHD', description: 'Attention deficit hyperactivity disorder affecting focus, impulse control, and behavior in children', category: 'Children', successRate: 78 },
    { name: 'Migraine', description: 'Severe recurring headaches with sensitivity to light, sound, and nausea', category: 'Chronic', successRate: 85 },
    { name: 'Kidney Stones', description: 'Hard mineral deposits in kidneys causing severe pain and urinary issues', category: 'Acute', successRate: 81 },
    { name: 'Autism Spectrum', description: 'Developmental disorder affecting communication, social interaction, and behavior', category: 'Children', successRate: 73 },
    { name: 'Eczema', description: 'Inflammatory skin condition causing dry, itchy, red patches and rashes', category: 'Chronic', successRate: 89 },
    { name: 'Hypothyroidism', description: 'Underactive thyroid gland causing fatigue, weight gain, and metabolic issues', category: 'Chronic', successRate: 91 },
    { name: 'Asthma', description: 'Respiratory condition causing breathing difficulty, wheezing, and chest tightness', category: 'Chronic', successRate: 84 },
    { name: 'Tonsillitis', description: 'Inflammation of tonsils causing sore throat, fever, and difficulty swallowing', category: 'Acute', successRate: 93 },
    { name: 'Depression', description: 'Mental health disorder affecting mood, energy, sleep, and daily functioning', category: 'Mental Health', successRate: 79 },
    { name: 'Arthritis', description: 'Joint inflammation causing pain, stiffness, swelling, and reduced mobility', category: 'Chronic', successRate: 82 },
    { name: 'Anxiety Disorders', description: 'Excessive worry, fear, and nervousness affecting daily life and relationships', category: 'Mental Health', successRate: 86 },
    { name: 'Acne', description: 'Skin condition causing pimples, blackheads, and inflammation on face and body', category: 'Chronic', successRate: 88 },
    { name: 'IBS', description: 'Irritable bowel syndrome causing abdominal pain, bloating, and irregular bowel movements', category: 'Chronic', successRate: 83 },
    { name: 'Sinusitis', description: 'Inflammation of sinus cavities causing facial pain, congestion, and headaches', category: 'Acute', successRate: 90 },
    { name: 'Menopause Symptoms', description: 'Hot flashes, mood swings, sleep issues during hormonal transition', category: 'Women', successRate: 85 },
    { name: 'Allergic Rhinitis', description: 'Hay fever causing sneezing, runny nose, and itchy eyes due to allergens', category: 'Chronic', successRate: 87 },
    { name: 'Vitiligo', description: 'Skin condition causing loss of pigmentation in patches', category: 'Chronic', successRate: 74 },
    { name: 'Urticaria', description: 'Hives causing itchy, raised welts on skin due to allergic reactions', category: 'Acute', successRate: 89 },
    { name: 'Insomnia', description: 'Sleep disorder causing difficulty falling asleep or staying asleep', category: 'Mental Health', successRate: 81 },
    { name: 'Gout', description: 'Inflammatory arthritis causing sudden severe joint pain and swelling', category: 'Chronic', successRate: 80 },
  ];

  const filteredDiseases = diseases.filter((disease) => {
    const matchesFilter = diseaseFilter === 'All' || disease.category === diseaseFilter;
    const matchesSearch = disease.name.toLowerCase().includes(diseaseSearch.toLowerCase()) ||
                          disease.description.toLowerCase().includes(diseaseSearch.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <>
      <Helmet>
        <title>Conditions We Treat - Dr. Shubhangi | Homeopathic Treatment for 100+ Diseases</title>
        <meta name="description" content="Comprehensive homeopathic treatment for chronic diseases, acute conditions, women's health, children's health, and mental health. 80-93% success rates." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">Conditions We Treat</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Effective homeopathic treatment for over 100 health conditions with proven success rates
              </p>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={diseaseSearch}
                  onChange={(e) => setDiseaseSearch(e.target.value)}
                  placeholder="Search a condition..."
                  className="w-full pl-12 pr-4 py-4 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                />
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-3 mb-12">
              {['All', 'Chronic', 'Acute', 'Children', 'Women', 'Mental Health'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setDiseaseFilter(filter)}
                  className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                    diseaseFilter === filter
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background text-foreground hover:bg-primary/10 border border-border'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDiseases.map((disease, index) => (
                <DiseaseCard key={index} {...disease} />
              ))}
            </div>

            {filteredDiseases.length === 0 && (
              <div className="text-center py-12">
                <p className="text-xl text-muted-foreground">No conditions found matching your search.</p>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default DiseasesPage;
