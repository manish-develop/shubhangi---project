
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Star } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TestimonialCard from '@/components/TestimonialCard.jsx';
import { useScrollAnimation } from '@/hooks/useScrollAnimation.js';
import { toast } from 'sonner';
import { validateRequired, validateEmail } from '@/utils/validation.js';

const TestimonialsPage = () => {
  const [heroRef, heroVisible] = useScrollAnimation(0.2);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    condition: '',
    testimonial: '',
    rating: 5,
  });

  const testimonials = [
    {
      name: 'Priya Sharma',
      city: 'Mumbai',
      rating: 5,
      testimonial: 'Dr. Shubhangi cured my chronic eczema that I had for 8 years. Her approach is truly holistic and she takes time to understand the root cause. Highly recommended!',
      condition: 'Eczema',
    },
    {
      name: 'Rajesh Kumar',
      city: 'Pune',
      rating: 5,
      testimonial: 'My daughter had recurrent tonsillitis and was advised surgery. After 6 months of treatment with Dr. Shubhangi, she has had no episodes. Thank you!',
      condition: 'Tonsillitis',
    },
    {
      name: 'Anita Desai',
      city: 'Delhi',
      rating: 5,
      testimonial: 'I struggled with PCOD for years. Dr. Shubhangi not only helped regulate my cycles but also improved my overall health. Her treatment is gentle yet effective.',
      condition: 'PCOD',
    },
    {
      name: 'Vikram Patel',
      city: 'Bangalore',
      rating: 5,
      testimonial: 'Suffered from severe migraines for 10 years. Conventional medicine only provided temporary relief. Dr. Shubhangi treatment has reduced frequency by 90%.',
      condition: 'Migraine',
    },
    {
      name: 'Meera Iyer',
      city: 'Chennai',
      rating: 5,
      testimonial: 'My son had ADHD and was struggling in school. After homeopathic treatment, his focus improved dramatically. We are so grateful to Dr. Shubhangi.',
      condition: 'ADHD',
    },
    {
      name: 'Arjun Mehta',
      city: 'Ahmedabad',
      rating: 5,
      testimonial: 'Chronic asthma made my life difficult. Dr. Shubhangi constitutional treatment has given me freedom from inhalers. I can breathe freely now.',
      condition: 'Asthma',
    },
    {
      name: 'Kavita Reddy',
      city: 'Hyderabad',
      rating: 5,
      testimonial: 'Hypothyroidism was affecting my energy and weight. Homeopathic treatment normalized my thyroid levels without any side effects. Amazing results!',
      condition: 'Hypothyroidism',
    },
    {
      name: 'Sanjay Gupta',
      city: 'Kolkata',
      rating: 5,
      testimonial: 'Psoriasis covered 40% of my body. After 8 months of treatment, it has cleared by 85%. Dr. Shubhangi gave me hope when nothing else worked.',
      condition: 'Psoriasis',
    },
    {
      name: 'Deepa Nair',
      city: 'Kochi',
      rating: 5,
      testimonial: 'Anxiety and panic attacks were ruining my life. Homeopathic treatment helped me regain control without any medications. Truly life-changing.',
      condition: 'Anxiety',
    },
  ];

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateRequired(formData.name)) {
      toast.error('Please enter your name');
      return;
    }

    if (!validateEmail(formData.email)) {
      toast.error('Please enter a valid email address');
      return;
    }

    if (!validateRequired(formData.condition)) {
      toast.error('Please enter the condition treated');
      return;
    }

    if (!validateRequired(formData.testimonial) || formData.testimonial.length < 50) {
      toast.error('Please write a testimonial of at least 50 characters');
      return;
    }

    toast.success('Thank you for sharing your experience. Your testimonial will be reviewed and published soon.');
    setFormData({ name: '', email: '', condition: '', testimonial: '', rating: 5 });
  };

  return (
    <>
      <Helmet>
        <title>Patient Testimonials - Dr. Shubhangi | Real Success Stories</title>
        <meta name="description" content="Read real patient testimonials and success stories from Dr. Shubhangi homeopathic clinic. 4.9★ rating with 5000+ happy patients." />
      </Helmet>

      <Header />

      <main>
        <section ref={heroRef} className="pt-32 pb-16 gradient-cream-mint leaf-pattern">
          <div className="container-custom">
            <div className={`text-center max-w-3xl mx-auto ${heroVisible ? 'animate-fade-in' : 'opacity-0'}`}>
              <h1 className="mb-6">Patient Testimonials</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Real stories from real people who found healing through homeopathy
              </p>
              <div className="flex items-center justify-center gap-3 mt-8">
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 fill-accent text-accent" />
                  ))}
                </div>
                <div className="text-2xl font-bold text-foreground">4.9/5</div>
                <div className="text-muted-foreground">from 500+ reviews</div>
              </div>
            </div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-custom">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard key={index} {...testimonial} />
              ))}
            </div>
          </div>
        </section>

        <section className="section-padding bg-muted">
          <div className="container-custom">
            <div className="max-w-2xl mx-auto">
              <div className="text-center mb-12">
                <h2 className="mb-4">Share Your Experience</h2>
                <p className="text-xl text-muted-foreground">
                  Help others by sharing your healing journey
                </p>
              </div>

              <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 card-shadow-lg">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Your Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                      placeholder="your.email@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Condition Treated</label>
                    <input
                      type="text"
                      value={formData.condition}
                      onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
                      placeholder="e.g., Eczema, PCOD, Migraine"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Your Rating</label>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          type="button"
                          onClick={() => setFormData({ ...formData, rating })}
                          className="transition-all duration-300"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              rating <= formData.rating
                                ? 'fill-accent text-accent'
                                : 'text-border'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Your Testimonial</label>
                    <textarea
                      value={formData.testimonial}
                      onChange={(e) => setFormData({ ...formData, testimonial: e.target.value })}
                      rows={6}
                      className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300 resize-none"
                      placeholder="Share your experience with Dr. Shubhangi treatment..."
                    />
                    <div className="text-sm text-muted-foreground mt-2">
                      Minimum 50 characters ({formData.testimonial.length}/50)
                    </div>
                  </div>

                  <button type="submit" className="w-full btn-primary">
                    Submit Testimonial
                  </button>
                </div>
              </form>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default TestimonialsPage;
